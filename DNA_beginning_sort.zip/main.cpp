#include <iostream>
#include <cstdio>
#include <cstring>
#include <fstream>
using namespace std;

const int INF = 100000000;
const int MAXN = 30000;        // max number of sequences
const int PLEN = 24;         // length of sample prefixes
const int MAXERR = 0.2;      // max error = 20%

const string file="failA.fasta";  // file to read sequences from
const string ofile="results.txt";   // file to write results to
string p[]={"AAGAAAGTTGTCGGTGTCTTTGTG", "TCGATTCCGTTTGTAGTCGTCTGT", "GAGTCTTGTGTCCCAGTTACCAGG", "TTCGGATTCTATCGTGTTTCCCTA", "CTTGTCCAGGGTTTGTGTAACCTT", "TTCTCGCAAAGGCAGAAAGTAGTC"};
string s[MAXN];  // dna sequences
int N, NP=6;    // number of sequences, number of prefixes/classes

const int subCost=1, delCost=1, addCost=1;  // costs/chances of mutations

int minED[MAXN], pclass[MAXN];
double serr[MAXN];      // error of i-th sequence prefix

int EDmem[PLEN+1][PLEN+7][6][MAXN];     // memoizacija


// calculates string edit distances
int editDistance(int i, int j, int pc, int sc)
{
    if(EDmem[i][j][pc][sc] != 0) return EDmem[i][j][pc][sc];
    if(i==0) return EDmem[i][j][pc][sc]=j;
    if(j==0) return EDmem[i][j][pc][sc]=i;

    if(p[pc][i-1]==s[sc][j-1])
        return EDmem[i][j][pc][sc]=editDistance(i-1, j-1, pc, sc);
    else
        return EDmem[i][j][pc][sc]=min(editDistance(i-1, j, pc, sc) + delCost,
                   min(editDistance(i, j-1, pc, sc) + addCost,
                       editDistance(i-1, j-1, pc, sc) + subCost));
}

void resetForN(int n, int p)
{
    for(int i=0;i<PLEN;i++)
        for(int j=0;j<PLEN+6;j++)
            EDmem[i][j][p][n]=0;
}

// read input sequences
void inputData(string f)
{
    ifstream fin(f.c_str());
    if(fin.is_open()) {
        string line;
        for(int i=0; fin >> line; i++) {
            s[i] = line;
            N = i+1;

            if(N%100 == 0) printf("%i\r", N);
        }
    } else {
        printf("Failed to open file.");
    }
    fin.close();
}

int main()
{
    //cin >> file;
    printf("Loading data...\n");
    inputData(file);

    printf("Loaded.\nAnalysing...\n");

    int prefixLen=PLEN;
    for(int i=0;i<N;i++) minED[i]=serr[i]=INF;

    // analyse
    for(int k=0;k<NP;k++)
    {
        for(int i=0;i<N;i++)
        {
            if(i%100 == 0) printf("Pattern %i/%i: %5i/%i\r", k+1, NP, i, N);

            if(s[i].length()<prefixLen) continue;   // skip sequence if it's shorter then prefix

            // calculate minimal edit distance from sample prefix to sequence prefix
            int minEDcurrent=INF;
            for(int j=0;j<6;j++)    // find optimal sequence prefix to consider
            {
                resetForN(i, k);

                int ed = editDistance(prefixLen, prefixLen+j, k, i);
                if(ed<=minEDcurrent)
                    minEDcurrent=ed;
                else
                    break;
            }

            if(minEDcurrent < minED[i])
            {
                minED[i] = minEDcurrent;
                pclass[i] = k+1;
                serr[i] = (double)minEDcurrent/prefixLen;
            }
        }
    }

    printf("\nSaving...\n");
    ofstream fout(ofile.c_str()), f[6];
    f[0].open("Pattern1.txt");
    f[1].open("Pattern2.txt");
    f[2].open("Pattern3.txt");
    f[3].open("Pattern4.txt");
    f[4].open("Pattern5.txt");
    f[5].open("Pattern6.txt");
    fout << "SEQUENCE\tEDIT DISTANCE\tERROR\tCLOSEST CLASS\n";
    for(int i=0;i<N;i++)
    {
        if(minED[i]!=INF)
        {
            fout << i+1 << ":\t\t" << minED[i] << ",\t\t" << 100.*serr[i] << "%,\t" << pclass[i] << endl;
            //printf("%5i: %2i %5.2f%% %i\n", i+1, minED[i], 100.*serr[i], pclass[i]);
            if(serr[i]<=MAXERR) {
                f[pclass[i]-1] << i+1 << ": " << minED[i] << ", " << 100.*serr[i] << "%    " << s[i] << endl;
            }
        }
        //else
        //    printf("%5i: xx xxxxx xx\n", i+1);
    }
    fout.close();
    for(int i=0;i<NP;i++) f[i].close();

    printf("Done.\nResults stored in %s.\n", ofile.c_str());

    return 0;
}
